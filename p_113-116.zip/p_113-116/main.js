function preload(){

}

function setup(){
    canvas = createCanvas(400,400);
    canvas.center();
}

function draw(){

}

function snapshot(){
    save("mustacefilter.png");
}